# # This is a sample Python script.
#
# # Press ⌃R to execute it or replace it with your code.
# # Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.
#
#
# from openai import OpenAI
#
# key = "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"
#
# # Create an OpenAI client with your secret key
# client = OpenAI(api_key=key)  # Replace with your own key or set OPENAI_API_KEY env variable
#
# # Define the prompt
# prompt = """הודעות קודמות בקבוצת וואטסאפ:
# 1. David: היי (:
# @972547718165 ואני מחפשים שותף/ה לפרויקט. מתכוונים לעבוד עליו ברצינות ולהוציא ציון טוב
# 2. מישהו: עד מתי צריך להגיש את הרעיונות לפרויקט?
# 3. Talia💕: 15 לאפריל
# 4. אליזבט פינחסוב: מישהו מסכם את ההרצאות ויכול לשתף?
# 5. מישהו: הייתה היום הרצאה?
# 6. מישהו: היי
# מחפש שותפ/ה לתרגילי בית, וזוג לפרוייקט גמר, דברו איתי :)
# 7. מישהו: או אם מישו יודע אם יש סיכומים בדרייב
# 8. מישהו: כן
# 9. מישהו: [No text]
# 10. מישהו: יש סיכום טוב לקורס?
# 11. מישהו: [No text]
# 12. מישהו: היי:)
# היום הצטרפתי לקורס והוא עדיין לא מופיע לי במודל, מתי הבוחן?
# 13. מישהו: [No text]
# 14. מישהו: 27/5
# 15. מישהו: תודה!
# 16. מישהו: מחפשים שותף שלישי לפרוייקט :)
# 17. מישהו: [No text]
# 18. מישהו: אשמח להסבר מה המטרה בפרוייקט - מה מצפים מאיתנו לעשות?
# 19. מישהו: בהרצאה הראשונה לקראת הסוף היא מסבירה די בפירוט מה הרעיון והמטרה של הפרויקט
# 20. Zenab Waked: מחפשת שותפ/ה לתרגילי בית
# 21. מישהו: [No text]
# 22. מישהו: [No text]
# 23. מישהו: [No text]
# 24. Aharon Cohen: הי!
# מחפש שותפ/ה  לתרגילי בית :)
#
# ההודעה הנוכחית:
# 25. Zenab Waked: עדיין רלוונטי
#
# על סמך ההקשר, מה הסבירות שההודעה הנוכחית היא תגובה לאחת ההודעות הקודמות?
# החזר רשימה של 25 מספרים בין 0 ל-1. כל מספר מייצג את הסיכוי שההודעה הנוכחית מגיבה להודעה בהתאמה מ-1 עד 25.
# """
#
# # Send to GPT-4o
# response = client.chat.completions.create(
#     model="gpt-4o",
#     messages=[
#         {"role": "user", "content": prompt}
#     ],
#     temperature=0.3
# )
#
# # Print only the reply vector
# print("\n📊 Estimated reply likelihoods:\n")
# print(response.choices[0].message.content)
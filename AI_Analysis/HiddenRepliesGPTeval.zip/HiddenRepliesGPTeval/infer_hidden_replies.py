
import json
import csv
import time
from pathlib import Path
from datetime import datetime
from openai import OpenAI

key = "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"

import json
import csv
import time
from pathlib import Path
from datetime import datetime
from openai import OpenAI
import re

def extract_reply_vector(text):
    # Case 1: Try to extract JSON-style list
    if "[" in text:
        try:
            json_part = text[text.find("["):text.find("]")+1]
            vector = eval(json_part)
            if isinstance(vector, list) and len(vector) == 25:
                return vector
        except Exception as e:
            print(f"❌ Failed to parse list with eval(): {e}")

    # Case 2: Fallback — parse numbered lines like "1. 0.2"
    numbered_lines = re.findall(r"\d+\.\s*([\d.]+)", text)
    if len(numbered_lines) == 25:
        try:
            return [float(val) for val in numbered_lines]
        except ValueError:
            print("❌ Failed to convert numbered lines to float.")
            return None

    print("⚠️ Could not extract valid 25-length reply vector.")
    return None

# 🔐 API key (or use env var OPENAI_API_KEY)
client = OpenAI(api_key=key)  # Replace with your actual key

# 📁 Input/output paths
JSON_PATH = "chat_data.json"
CACHE_PATH = "gpt_cache.jsonl"
CSV_PATH = "inferred_hidden_replies.csv"

# 📦 Load chat messages
with open(JSON_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)
    messages = data["messages"]

# ✅ Filter malformed messages
messages = [
    m for m in messages
    if isinstance(m, dict)
    and "body" in m
    and isinstance(m.get("sender"), dict)
]

# ✅ Sort by timestamp
messages.sort(key=lambda m: m["datetime"])

# 💾 Load cache
cache = {}
if Path(CACHE_PATH).exists():
    with open(CACHE_PATH, "r", encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line.strip())
            cache[entry["messageId"]] = entry["reply_vector"]

# 🧠 Sender label function (robust fallback)
def format_sender(m):
    sender = m.get("sender", {})
    return (
        sender.get("pushname") or
        sender.get("phone") or
        sender.get("id") or
        "מישהו"
    )

# 🧠 Prompt builder
def build_prompt(window, target):
    context = "\n".join(
        f"{i+1}. {format_sender(m)}: {m.get('body', '[No text]')}"
        for i, m in enumerate(window)
    )
    target_str = f"{len(window)+1}. {format_sender(target)}: {target.get('body', '[No text]')}"

    return f"""הודעות קודמות בקבוצת וואטסאפ:
{context}

ההודעה הנוכחית:
{target_str}

על סמך ההקשר, מה הסבירות שההודעה הנוכחית היא תגובה לאחת ההודעות הקודמות?
החזר רשימה של 25 מספרים בין 0 ל-1. כל מספר מייצג את הסיכוי שההודעה הנוכחית מגיבה להודעה בהתאמה מ-1 עד 25.
"""

# 📄 Prepare CSV writer
csv_file = open(CSV_PATH, "w", newline="", encoding="utf-8")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["serialNumber", "messageId"] + [f"reply_to_index_{i+1}" for i in range(25)])

# 🔁 Loop through messages
for i in range(25, len(messages)):
    target = messages[i]
    msg_id = target["messageId"]

    # Skip explicit replies or previously processed
    if target.get("replyTo") or msg_id in cache:
        continue

    # Skip empty/no-text messages
    if not isinstance(target.get("body"), str) or target["body"].strip() == "":
        continue

    window = messages[i - 25:i]

    # Skip if all window messages are empty
    if all(not isinstance(m.get("body"), str) or m["body"].strip() == "" for m in window):
        continue

    prompt = build_prompt(window, target)

    try:
        # 🧠 GPT-4o call
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0
        )



        text = response.choices[0].message.content.strip()
        print(f"\n📥 GPT raw output for message {target['serialNumber']} ({msg_id}):\n{text}\n")

        reply_vector = extract_reply_vector(text)
        if not reply_vector:
            continue

        # ✅ Write to CSV
        csv_writer.writerow([target["serialNumber"], msg_id] + reply_vector)

        # ✅ Append to cache
        with open(CACHE_PATH, "a", encoding="utf-8") as f_cache:
            json.dump({
                    "messageId"   : msg_id,
                    "serialNumber": target["serialNumber"],
                    "reply_vector": reply_vector,
                    "timestamp"   : datetime.utcnow().isoformat(),
                    "gpt_response": text
            }, f_cache, ensure_ascii=False)
            f_cache.write("\n")

        print(f"✅ Cached and saved message {target['serialNumber']}")

        # 🕒 Optional delay
        time.sleep(0.2)

    except Exception as e:
        print(f"❌ Error on message {target['serialNumber']} ({msg_id}): {e}")
        time.sleep(2)

csv_file.close()
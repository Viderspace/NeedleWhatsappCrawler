import json
import csv
import matplotlib.pyplot as plt

# Load messages from chat_data.json
with open("chat_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)
    messages = data["messages"]

# Build a lookup by serialNumber
serial_lookup = {msg["serialNumber"]: msg for msg in messages if isinstance(msg, dict)}

# Load GPT cache responses
gpt_outputs = []
with open("gpt_cache.jsonl", "r", encoding="utf-8") as f:
    for line in f:
        gpt_outputs.append(json.loads(line))

# Robust sender extraction
def get_sender(msg):
    sender = msg.get("sender")
    if isinstance(sender, dict):
        return sender.get("pushname") or sender.get("phone") or sender.get("id", "Unknown")
    elif isinstance(sender, str):
        return sender
    else:
        return "Unknown"

# Prepare output rows
rows = []

for entry in gpt_outputs:
    serial = entry["serialNumber"]
    analyzed_msg = serial_lookup.get(serial)

    if not analyzed_msg:
        print(f"⚠️ Message {serial} not found in chat_data.json")
        continue

    # Sort top reply candidates
    reply_vector = entry["reply_vector"]
    top_indices = sorted(
        range(len(reply_vector)),
        key=lambda i: reply_vector[i],
        reverse=True
    )
    # Strictly top 2 replies (ignore ties beyond 2nd place)
    top_scores = [
            (i + 1, reply_vector[i])
            for i in sorted(range(len(reply_vector)), key=lambda x: reply_vector[x], reverse=True)[:2]
    ]
    # Compose row
    row = {
        "Analyzed Serial": serial,
        "Analyzed Sender": get_sender(analyzed_msg),
        "Analyzed Body": analyzed_msg.get("body", "[No Text]"),
        "GPT Explanation": entry.get("gpt_response", "").replace("\n", " "),
    }

    # for idx, (reply_serial, score) in enumerate(top_scores, 1):
    #     reply_msg = serial_lookup.get(reply_serial)
    # First, get the index of the analyzed message
    try:
        analyzed_index = messages.index(analyzed_msg)
    except ValueError:
        print(f"⚠️ Could not find index of message {serial}")
        continue

    for idx, (gpt_index, score) in enumerate(top_scores, 1):
        reply_index = analyzed_index - 26 + gpt_index
        if 0 <= reply_index < len(messages):
            reply_msg = messages[reply_index]
            reply_serial = reply_msg.get("serialNumber")
        else:
            reply_msg = None
            reply_serial = f"[Out of Bounds: idx={reply_index}]"

        row[f"Top{idx} Reply Serial"] = reply_serial
        row[f"Top{idx} Sender"] = get_sender(reply_msg) if reply_msg else "[Missing]"
        row[f"Top{idx} Body"] = reply_msg.get("body", "[No Text]") if reply_msg else "[Missing]"
        row[f"Top{idx} GPT Score"] = f"{score:.2f}"

    # Only include row if highest score ≥ threshold
    THRESHOLD = 0.35
    if top_scores and top_scores[0][1] >= THRESHOLD:
        rows.append(row)
    # rows.append(row)



output_file = "inferred_hidden_replies_top_thresh35_percent.csv"

# Build full field list across all rows
fieldnames = set()
for row in rows:
    fieldnames.update(row.keys())
fieldnames = sorted(fieldnames)

with open(output_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print(f"✅ Exported {len(rows)} rows to {output_file}")



for entry in gpt_outputs:
    if max(entry["reply_vector"]) > 1:
        print(f"⚠️ Message {entry['serialNumber']} has out-of-bound score: {max(entry['reply_vector'])}")

top_scores = [
    max(entry["reply_vector"])
    for entry in gpt_outputs
    if isinstance(entry["reply_vector"], list)
    and all(isinstance(x, (int, float)) for x in entry["reply_vector"])
    and max(entry["reply_vector"]) <= 1
]



plt.figure(figsize=(8, 5))
plt.hist(top_scores, bins=20, edgecolor='black')
plt.title("Distribution of Top GPT-Inferred Reply Scores")
plt.xlabel("Top GPT Score")
plt.ylabel("Count")
plt.grid(True)

# Optional: add a line to suggest an initial threshold
plt.axvline(x=0.35, color='red', linestyle='--', label='Suggested threshold = 0.35')
plt.legend()
plt.show()